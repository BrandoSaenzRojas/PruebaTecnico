// class utils{
//     static Comparar (a,b) {
//         if(a!=b){
//             return true;
//         }else{
//             return false;
//         }
//     }
// };


// module.exports = utils;