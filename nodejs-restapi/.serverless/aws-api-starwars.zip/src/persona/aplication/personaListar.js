const { DynamoDB } = require('aws-sdk');
const dynamoDb = new DynamoDB.DocumentClient();


async function obtenerPersonas(event) {
  console.log(event);
  const params = {
    TableName: process.env.PERSONA_DYNAMODB_TABLE
  }
  return dynamoDb.scan(params)
    .promise()
    .then(response =>{
      
      return {data:response.Items};
    })
    .catch(error =>{
      console.error(error);
      return {message: 'erro en dynamoDb'}
    })
  
}
module.exports = obtenerPersonas;
