// const registrar = require('../../../../src/planeta/aplication/planetaRegistrar');

 
// it('Test Fn(getOperation)', async() => {
//     const result = {
//         "message": "erro en dynamoDb"
//     };
//     const event = {
//         body: '{\r\n' +
//           '"id":"1",\r\n' +
//           '"url":"www.peru.com",\r\n' +
//           '"editado":"true",\r\n' +
//           '"creado":"Si",\r\n' +
//           '"filmes":"123",\r\n' +
//           '"residentes":"123",\r\n' +
//           '"poblacion":"123",\r\n' +
//           '"superficie_agua":"1",\r\n' +
//           '"terreno":"123"\r\n' +
//           '}',
//         headers: {
//           'Content-Type': 'application/json',
//           'User-Agent': 'PostmanRuntime/7.26.5',
//           Accept: '*/*',
//           'Postman-Token': 'b5188f52-a58d-4c9e-8444-df24fb111638',
//           Host: 'localhost:3000',
//           'Accept-Encoding': 'gzip, deflate, br',
//           Connection: 'keep-alive',
//           'Content-Length': '172'
//         },
//         httpMethod: 'POST',
//         isBase64Encoded: false,
//         multiValueHeaders: {
//           'Content-Type': [ 'application/json' ],
//           'User-Agent': [ 'PostmanRuntime/7.26.5' ],
//           Accept: [ '*/*' ],
//           'Postman-Token': [ 'b5188f52-a58d-4c9e-8444-df24fb111638' ],
//           Host: [ 'localhost:3000' ],
//           'Accept-Encoding': [ 'gzip, deflate, br' ],
//           Connection: [ 'keep-alive' ],
//           'Content-Length': [ '172' ]
//         },
//         multiValueQueryStringParameters: null,
//         path: '/crearPlaneta',
//         pathParameters: null,
//         queryStringParameters: null,
//         requestContext: {
//           accountId: 'offlineContext_accountId',
//           apiId: 'offlineContext_apiId',
//           authorizer: {
//             claims: undefined,
//             scopes: undefined,
//             principalId: 'offlineContext_authorizer_principalId'
//           },
//           domainName: 'offlineContext_domainName',
//           domainPrefix: 'offlineContext_domainPrefix',
//           extendedRequestId: 'ckgee26wt000018ttc0w177fs',
//           httpMethod: 'POST',
//           identity: {
//             accessKey: null,
//             accountId: 'offlineContext_accountId',
//             apiKey: 'offlineContext_apiKey',
//             caller: 'offlineContext_caller',
//             cognitoAuthenticationProvider: 'offlineContext_cognitoAuthenticationProvider',
//             cognitoAuthenticationType: 'offlineContext_cognitoAuthenticationType',
//             cognitoIdentityId: 'offlineContext_cognitoIdentityId',
//             cognitoIdentityPoolId: 'offlineContext_cognitoIdentityPoolId',
//             principalOrgId: null,
//             sourceIp: '127.0.0.1',
//             user: 'offlineContext_user',
//             userAgent: 'PostmanRuntime/7.26.5',
//             userArn: 'offlineContext_userArn'
//           },
//           path: '/crearPlaneta',
//           protocol: 'HTTP/1.1',
//           requestId: 'ckgee26wu000118ttfk139u7i',
//           requestTime: '17/Oct/2020:19:45:42 -0500',
//           requestTimeEpoch: 1602981942629,
//           resourceId: 'offlineContext_resourceId',
//           resourcePath: '/dev/crearPlaneta',
//           stage: 'dev'
//         },
//         resource: '/dev/crearPlaneta',
//         stageVariables: null
//       };
//     const data = await registrar(event);
//     expect(data).toEqual(result);
// });